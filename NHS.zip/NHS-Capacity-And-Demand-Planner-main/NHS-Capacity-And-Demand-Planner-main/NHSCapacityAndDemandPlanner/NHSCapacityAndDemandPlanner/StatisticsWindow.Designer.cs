﻿
namespace NHSCapacityAndDemandPlanner
{
    partial class StatisticsWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BackButton = new Button();
            ClinicLabel = new Label();
            TheatreLabel = new Label();
            LeaveLabel = new Label();
            SickLabel = new Label();
            ExpectedPatientsInput = new TextBox();
            ExpectedPatientsText = new Label();
            CapacityResultLabel = new Label();
            NextWeekButton = new Button();
            PreviousWeekButton = new Button();
            SuspendLayout();
            // 
            // BackButton
            // 
            BackButton.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BackButton.Location = new Point(12, 12);
            BackButton.Name = "BackButton";
            BackButton.Size = new Size(118, 40);
            BackButton.TabIndex = 1;
            BackButton.Text = "Back";
            BackButton.UseVisualStyleBackColor = true;
            BackButton.Click += BackButton_Click;
            // 
            // ClinicLabel
            // 
            ClinicLabel.BackColor = SystemColors.ActiveCaption;
            ClinicLabel.Font = new Font("Segoe UI", 20F);
            ClinicLabel.Location = new Point(12, 107);
            ClinicLabel.Name = "ClinicLabel";
            ClinicLabel.Size = new Size(278, 37);
            ClinicLabel.TabIndex = 2;
            ClinicLabel.Text = "Clinics : 0";
            ClinicLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TheatreLabel
            // 
            TheatreLabel.BackColor = SystemColors.ActiveCaption;
            TheatreLabel.Font = new Font("Segoe UI", 20F);
            TheatreLabel.Location = new Point(12, 144);
            TheatreLabel.Name = "TheatreLabel";
            TheatreLabel.Size = new Size(278, 37);
            TheatreLabel.TabIndex = 3;
            TheatreLabel.Text = "Theatre: 0";
            TheatreLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LeaveLabel
            // 
            LeaveLabel.BackColor = SystemColors.ActiveCaption;
            LeaveLabel.Font = new Font("Segoe UI", 20F);
            LeaveLabel.Location = new Point(12, 181);
            LeaveLabel.Name = "LeaveLabel";
            LeaveLabel.Size = new Size(278, 37);
            LeaveLabel.TabIndex = 4;
            LeaveLabel.Text = "Leave: 0";
            LeaveLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // SickLabel
            // 
            SickLabel.BackColor = SystemColors.ActiveCaption;
            SickLabel.Font = new Font("Segoe UI", 20F);
            SickLabel.Location = new Point(12, 218);
            SickLabel.Name = "SickLabel";
            SickLabel.Size = new Size(278, 39);
            SickLabel.TabIndex = 5;
            SickLabel.Text = "Sick: 0";
            SickLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // ExpectedPatientsInput
            // 
            ExpectedPatientsInput.BackColor = SystemColors.HotTrack;
            ExpectedPatientsInput.Location = new Point(444, 162);
            ExpectedPatientsInput.Name = "ExpectedPatientsInput";
            ExpectedPatientsInput.Size = new Size(100, 23);
            ExpectedPatientsInput.TabIndex = 6;
            ExpectedPatientsInput.TextChanged += ExpectedPatientsInput_TextChanged;
            // 
            // ExpectedPatientsText
            // 
            ExpectedPatientsText.AutoSize = true;
            ExpectedPatientsText.BackColor = SystemColors.Info;
            ExpectedPatientsText.Location = new Point(416, 144);
            ExpectedPatientsText.Name = "ExpectedPatientsText";
            ExpectedPatientsText.Size = new Size(168, 15);
            ExpectedPatientsText.TabIndex = 7;
            ExpectedPatientsText.Text = "Input Expected Patients Below:";
            // 
            // CapacityResultLabel
            // 
            CapacityResultLabel.AutoSize = true;
            CapacityResultLabel.Location = new Point(456, 89);
            CapacityResultLabel.Name = "CapacityResultLabel";
            CapacityResultLabel.Size = new Size(88, 15);
            CapacityResultLabel.TabIndex = 8;
            CapacityResultLabel.Text = "Capacity Status";
            // 
            // NextWeekButton
            // 
            NextWeekButton.Location = new Point(154, 81);
            NextWeekButton.Name = "NextWeekButton";
            NextWeekButton.Size = new Size(136, 23);
            NextWeekButton.TabIndex = 9;
            NextWeekButton.Text = "Next Week";
            NextWeekButton.UseVisualStyleBackColor = true;
            NextWeekButton.Click += NextWeekButton_Click;
            // 
            // PreviousWeekButton
            // 
            PreviousWeekButton.Location = new Point(12, 81);
            PreviousWeekButton.Name = "PreviousWeekButton";
            PreviousWeekButton.Size = new Size(136, 23);
            PreviousWeekButton.TabIndex = 10;
            PreviousWeekButton.Text = "Previous Week";
            PreviousWeekButton.UseVisualStyleBackColor = true;
            PreviousWeekButton.Click += PreviousWeekButton_Click;
            // 
            // StatisticsWindow
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1184, 761);
            Controls.Add(PreviousWeekButton);
            Controls.Add(NextWeekButton);
            Controls.Add(CapacityResultLabel);
            Controls.Add(ExpectedPatientsText);
            Controls.Add(ExpectedPatientsInput);
            Controls.Add(SickLabel);
            Controls.Add(LeaveLabel);
            Controls.Add(TheatreLabel);
            Controls.Add(ClinicLabel);
            Controls.Add(BackButton);
            MinimumSize = new Size(1200, 800);
            Name = "StatisticsWindow";
            Text = "Statistics";
            Load += StatisticsWindow_Load;
            ResumeLayout(false);
            PerformLayout();
        }




        #endregion

        private Button BackButton;
        private Label ClinicLabel;
        private Label TheatreLabel;
        private Label LeaveLabel;
        private Label SickLabel;
        private TextBox ExpectedPatientsInput;
        private Label ExpectedPatientsText;
        private Label CapacityResultLabel;
        private Button NextWeekButton;
        private Button PreviousWeekButton;
    }
}