﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NHSCapacityAndDemandPlanner
{
    public partial class StatisticsWindow : Form
    {
        int clinics = 0;
        int theatre = 0;
        int leave = 0;
        int sick = 0;
        int currentWeek = 1;
        public StatisticsWindow()
        {
            InitializeComponent();
        }

        private void StatisticsWindow_Load(object sender, EventArgs e)
        {
            LoadStatistics();

        }

        private void LoadStatistics()
        {
            clinics = 0;
            theatre = 0;
            leave = 0;
            sick = 0;
            string fileName = $"ClinicianTimeTableWeek{currentWeek}.json";

            ReadJSON reader = new ReadJSON();

            string path = Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "JSONdata",
                fileName
            );

            string root = reader.GetRoot(fileName);

            var result = reader.JsonTo2DArray(path, root);

            for (int r = 0; r < result.data.GetLength(0); r++)
            {
                for (int c = 0; c < result.data.GetLength(1); c++)
                {
                    string value = result.data[r, c].ToLower();

                    if (value.Contains("clinic")) clinics++;
                    else if (value.Contains("theatre")) theatre++;
                    else if (value.Contains("leave")) leave++;
                    else if (value.Contains("sick")) sick++;
                }
            }

            ClinicLabel.Text = $"Clinics: {clinics}";
            TheatreLabel.Text = $"Theatre: {theatre}";
            LeaveLabel.Text = $"Leave: {leave}";
            SickLabel.Text = $"Sick: {sick}";
        }


        private void BackButton_Click(object sender, EventArgs e)
        {
            HomeWindow homeWindow = new HomeWindow();
            homeWindow.Show();
            this.Hide();
        }

        private void DemandInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void ExpectedPatientsInput_TextChanged(object sender, EventArgs e)
        {
            UpdateCapacity();
        }

        private void UpdateCapacity()
        {
            int estimatedCapacity = clinics * 10;

            int expectedPatients = 0;
            int.TryParse(ExpectedPatientsInput.Text, out expectedPatients);

            if (estimatedCapacity < expectedPatients)
            {
                CapacityResultLabel.Text = " Capacity below expected demand";
                CapacityResultLabel.ForeColor = Color.Red;
            }
            else
            {
                CapacityResultLabel.Text = "Capacity sufficient";
                CapacityResultLabel.ForeColor = Color.Green;
            }
        }

        private void NextWeekButton_Click(object sender, EventArgs e)
        {
            if (currentWeek < 2)
                currentWeek++;
            LoadStatistics();

        }

        private void PreviousWeekButton_Click(object sender, EventArgs e)
        {
            if (currentWeek > 1)
                currentWeek--;

            LoadStatistics();

        }

        public EventHandler SchedulerWindow_Load { get; private set; }
    }
}
